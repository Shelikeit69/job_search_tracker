COMMON RULES (extraction only, no analysis)

Setup: Gmail tools are deferred. First call ToolSearch with query "select:mcp__Gmail__search_threads,mcp__Gmail__get_thread,mcp__Gmail__get_message" (max_results 5).

Integrity (every record will be spot-checked against Gmail by message ID):
1. Only write records for messages you actually saw in a tool result in THIS task. You have no prior history and there is no earlier data. Never infer, fill in or invent messages, IDs, titles or companies.
2. Copy msg_id (`id`), thread_id (`threadId`) and date (`date`) exactly as returned.
3. Decode HTML entities (&amp; -> &, &#39; -> ', &quot; -> ").
4. search_threads previews show at most ~5 oldest messages per thread. If a preview shows 5 messages, call get_thread (messageFormat MINIMAL) to get all messages.
5. Use pageSize 50 and follow nextPageToken until there is none. Ignore resultCountEstimate.
6. Write incrementally after each page with Bash and a quoted heredoc:
   cat >> /home/claude/jobdb/raw/FILE.jsonl <<'EOF2'
   {"cat": "...", "msg_id": "...", ...}
   EOF2
   One valid JSON object per line (escape " inside strings as \").
7. Write each msg_id once.
8. If a tool call errors, retry once; if it still fails append {"error": "<what failed>"} and continue.
9. Keep the "subject" field exactly as shown (after entity decoding); that is the field we parse later.

Final reply (under 150 words): total records, count per year-month (UTC, from date), oldest and newest date seen, and any errors or unusual formats. Do not paste the records.
