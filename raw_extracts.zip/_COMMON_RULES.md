COMMON RULES FOR ALL EXTRACTION AGENTS

Purpose: build a personal job-search database for the mailbox owner (Toni). You extract email METADATA into a JSONL file. Extraction only — no analysis.

Setup: Gmail tools are deferred. First call ToolSearch with query "select:mcp__Gmail__search_threads,mcp__Gmail__get_thread" (max_results 5).

Integrity (records will be spot-checked against Gmail by message ID):
1. Only write records for messages you actually saw in a tool result in THIS task. You have no prior history and there is no earlier data. Never infer, fill in, or invent messages, IDs, titles or companies.
2. Copy msg_id (`id`), thread_id (`threadId`) and date (`date`) exactly as returned.
3. Decode HTML entities in text (&amp; -> &, &#39; -> ').
4. search_threads previews show at most ~5 oldest messages per thread. If a thread preview shows 5 messages, call get_thread (messageFormat MINIMAL) on it to get all messages.
5. Use pageSize 50 and follow nextPageToken until there is none.
6. Write incrementally: after each page / each get_thread, append that batch to your output file with Bash using a quoted heredoc:
   cat >> /home/claude/jobdb/raw/FILE.jsonl <<'EOF2'
   {"cat": "...", ...}
   EOF2
   One valid JSON object per line (escape " inside strings as \").
7. Write each msg_id once (dedupe within your file).
8. If a tool call errors, retry once; if it still fails append {"error": "<what failed>"} and continue.

Final reply (under 150 words): total records written, count per year-month by the date field (UTC), number of get_thread calls, and any errors/oddities. Do not paste the records.
